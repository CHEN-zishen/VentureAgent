const express = require('express');
const cors = require('cors');

const app = express();
const PORT = 3000;

app.use(cors());
app.use(express.json());

// DeepSeek API 配置
// 请在环境变量中设置 DEEPSEEK_API_KEY，或直接替换下面的空字符串
const DEEPSEEK_API_KEY = process.env.DEEPSEEK_API_KEY || '';
const DEEPSEEK_API_URL = 'https://api.deepseek.com/v1/chat/completions';

app.post('/api/evaluate', async (req, res) => {
  try {
    const { type, content } = req.body;
    
    if (!content || !type) {
      return res.status(400).json({ error: '缺少必要参数' });
    }

    const typePrompts = {
      business_plan: `
        你是一位资深的商业分析师，请对以下商业计划书进行评估分析：
        1. 分析商业模式的可行性和创新性
        2. 评估市场潜力和竞争优势
        3. 分析团队能力和资源匹配度
        4. 识别潜在风险和挑战
        5. 给出综合评分（0-100分）和优化建议
        
        请以JSON格式输出，包含以下字段：
        - overallScore: 综合评分（整数）
        - grade: 等级（A+/A/B+/B/C）
        - businessModelScore: 商业模式评分（0-100）
        - marketPotentialScore: 市场潜力评分（0-100）
        - teamCapabilityScore: 团队能力评分（0-100）
        - riskLevelScore: 风险控制评分（0-100）
        - advantages: 核心优势数组
        - risks: 潜在风险数组
        - suggestions: 优化建议数组
        
        商业计划书内容：
        `,
      investment: `
        你是一位资深的投资分析师，请对以下投资项目进行评估分析：
        1. 分析投资价值和回报潜力
        2. 评估市场竞争力和壁垒
        3. 分析财务状况和估值合理性
        4. 识别投资风险和退出策略
        
        请以JSON格式输出，包含以下字段：
        - overallScore: 综合评分（整数）
        - grade: 等级（A+/A/B+/B/C）
        - businessModelScore: 商业模式评分（0-100）
        - marketPotentialScore: 市场潜力评分（0-100）
        - teamCapabilityScore: 团队能力评分（0-100）
        - riskLevelScore: 风险控制评分（0-100）
        - advantages: 核心优势数组
        - risks: 潜在风险数组
        - suggestions: 优化建议数组
        
        投资项目信息：
        `,
      market: `
        你是一位市场研究专家，请对以下市场分析需求进行分析：
        1. 分析目标市场规模和增长趋势
        2. 评估竞争格局和市场份额
        3. 分析消费者需求和行为特征
        4. 识别市场机会和挑战
        
        请以JSON格式输出，包含以下字段：
        - overallScore: 综合评分（整数）
        - grade: 等级（A+/A/B+/B/C）
        - businessModelScore: 商业模式评分（0-100）
        - marketPotentialScore: 市场潜力评分（0-100）
        - teamCapabilityScore: 团队能力评分（0-100）
        - riskLevelScore: 风险控制评分（0-100）
        - advantages: 核心优势数组
        - risks: 潜在风险数组
        - suggestions: 优化建议数组
        
        市场分析需求：
        `,
      risk: `
        你是一位风险管理专家，请对以下项目进行风险评估：
        1. 识别潜在风险因素
        2. 评估风险概率和影响程度
        3. 分析风险传导路径
        4. 提供风险应对策略
        
        请以JSON格式输出，包含以下字段：
        - overallScore: 综合评分（整数）
        - grade: 等级（A+/A/B+/B/C）
        - businessModelScore: 商业模式评分（0-100）
        - marketPotentialScore: 市场潜力评分（0-100）
        - teamCapabilityScore: 团队能力评分（0-100）
        - riskLevelScore: 风险控制评分（0-100）
        - advantages: 核心优势数组
        - risks: 潜在风险数组
        - suggestions: 优化建议数组
        
        项目信息：
        `
    };

    const prompt = typePrompts[type] || typePrompts.business_plan;

    const response = await fetch(DEEPSEEK_API_URL, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${DEEPSEEK_API_KEY}`
      },
      body: JSON.stringify({
        model: 'deepseek-chat',
        messages: [
          {
            role: 'user',
            content: prompt + content
          }
        ],
        temperature: 0.7,
        max_tokens: 2048
      })
    });

    const data = await response.json();
    
    if (data.error) {
      throw new Error(data.error.message || 'API调用失败');
    }

    const resultContent = data.choices[0].message.content;
    
    try {
      const jsonResult = JSON.parse(resultContent);
      res.json(jsonResult);
    } catch {
      res.json({
        success: false,
        message: resultContent
      });
    }
  } catch (error) {
    console.error('API调用错误:', error);
    res.status(500).json({
      success: false,
      error: error.message
    });
  }
});

app.get('/api/health', (req, res) => {
  res.json({ status: 'ok', timestamp: new Date().toISOString() });
});

app.listen(PORT, () => {
  console.log(`Server running on http://localhost:${PORT}`);
});